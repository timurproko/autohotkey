#Include D:\Dropbox\Configs\AutoHotkey\_scripts\_mytools\mytools_functions.ahk
#Requires AutoHotkey >=v2.0
#NoTrayIcon
#SingleInstance Force
KeyHistory(0)
ListLines(false)
ProcessSetPriority("A")
SetWinDelay (-1)
SetKeyDelay (-1, -1, -1)
SetMouseDelay (-1)
SetControlDelay (-1)
A_HotkeyInterval := 0

; Reallusion
characterCreator := "ahk_exe CharacterCreator.exe"
iClone := "ahk_exe iClone.exe"

#HotIf WinActive(characterCreator) and NotClassNN("Edit1") or WinActive(iClone) and NotClassNN("Edit1")
    *Space::    Send("{Alt Down}")
    *Space Up:: Send("{Alt Up}")
#HotIf
#HotIf WinActive("Morph Slider Editor")
    Space::     Send("{Space}")
#HotIf
#HotIf WinActive(characterCreator) and NotClassNN("Edit1")
    ^,::        Send("^p")
    ^.::        Send("^+p")
    ^p::        Send("{f6}")
    Up::        Send("{Space}")
    h::         Send("{Home}")
    +Left::     Send(",")
    +Right::    Send(".")
    F11::       Toggle("^6", "^3")
#HotIf
#HotIf WinActive(iClone)
    Up::        Send("{Space}")
    F11::       Toggle("^7", "^2")
#HotIf

; ; InstaMAT
; #HotIf WinActive("ahk_exe InstaMAT Studio.exe")
;     *sc056::    Send("!c")
;     !1::        Send("+1")
;     !2::        Send("+2")
;     !3::        Send("+3")
;     !Left::     Send("^{Left}")
;     !Right::    Send("^{Right}")
;     !Up::       Send("^{Up}")
;     !Down::     Send("^{Down}")
; #HotIf
; #HotIf WinActive("ahk_exe InstaMAT Studio.exe") and !FocusedText("InstaMAT Studio")
;     Space::     Send("{Space Down}")
;     Space Up::  Send("{Space Up}")
; #HotIf
; #HotIf WinActive("ahk_exe InstaMAT Studio.exe") and FocusedText("InstaMAT Studio")
;     *sc056::    Send("!c")
;     *Space::    Send("{Alt Down}")
;     *Space Up:: Send("{Alt Up}")
; #HotIf

; #HotIf WinActive("ahk_exe InstaMAT Studio.exe") and !WinExist("Raytracing")
;     ^+r::       Send("^+r")
; #HotIf
; #HotIf WinActive("ahk_exe InstaMAT Studio.exe") and !WinActive("Raytracing")
;     ^+r::       WinActivate("Raytracing")
; #HotIf
; #HotIf WinActive("ahk_exe InstaMAT Studio.exe") and WinActive("Raytracing")
;     ^+r::       WinClose()
;     Escape::    WinClose()
; #HotIf

; #HotIf WinActive("ahk_exe InstaMAT Studio.exe") and !WinExist("Mesh Baking")
;     ^+b::{
;         Send("^+b")
;         Sleep 25
;         if WinExist("Mesh Baking")
;             WinActivate
;     }
; #HotIf
; #HotIf WinActive("ahk_exe InstaMAT Studio.exe") and !WinActive("Mesh Baking")
;     ^+b::       WinActivate("Mesh Baking")
; #HotIf
; #HotIf WinActive("ahk_exe InstaMAT Studio.exe") and WinActive("Mesh Baking")
;     ^+b::       WinClose()
;     Escape::    WinClose()
; #HotIf

; #HotIf WinActive("ahk_exe InstaMAT Studio.exe") and !WinExist("Image and Data Output Export")
;     ^+o::       Send("^o")
;     ^o::        return
; #HotIf
; #HotIf WinActive("ahk_exe InstaMAT Studio.exe") and !WinActive("Image and Data Output Export")
;     ^+o::       WinActivate("Image and Data Output Export")
; #HotIf
; #HotIf WinActive("ahk_exe InstaMAT Studio.exe") and WinActive("Image and Data Output Export")
;     ^+o::       WinClose()
;     Escape::    WinClose()
; #HotIf

; ; Faceform Wrap
; #HotIf WinActive("ahk_exe Wrap.exe")
;     ^,:: Send("^p")
; #HotIf

; ; Omniverse
; #HotIf WinActive("ahk_exe kit.exe")
;     Tab:: return
; #HotIf

; ; RizomUV
; #HotIf WinActive("ahk_exe rizomuv.exe") and WinActive("Preferences") or WinActive("Keyboard and Mouse Customizer Dialog")
;     Escape::    WinClose()
; #HotIf

; #HotIf WinActive("ahk_exe rizomuv.exe") and WinActive("Script and Log Window")
;     Escape::    WinClose()
;     L::         WinClose()
; #HotIf

; ; ZBrush
; #HotIf WinActive("ahk_exe ZBrush.exe")
;     #z::        WinMinimize()
; #HotIf

; ; Spline
; #HotIf WinActive("ahk_exe Spline.exe")
;     *Space::    Send("{Alt Down}")
;     *Space Up:: Send("{Alt Up}")
; #HotIf
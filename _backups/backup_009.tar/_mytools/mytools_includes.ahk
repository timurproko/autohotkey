﻿#Include D:\Dropbox\Configs\AutoHotkey\_scripts\_mytools\mytools_constants.ahk
#Include D:\Dropbox\Configs\AutoHotkey\_scripts\_mytools\mytools_functions.ahk

#Requires AutoHotkey >=v2.0
#NoTrayIcon
#SingleInstance Force
KeyHistory(0)
ListLines(false)
ProcessSetPriority("A")
SetWinDelay (-1)
SetKeyDelay (-1, -1, -1)
SetMouseDelay (-1)
SetControlDelay (-1)
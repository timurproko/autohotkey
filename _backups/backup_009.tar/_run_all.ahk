#Requires AutoHotkey >=v2.0
#NoTrayIcon
#SingleInstance Force
KeyHistory(0)

Run("AutoHotkey.exe " A_ScriptDir "\apps_3d.ahk")
Run("AutoHotkey.exe " A_ScriptDir "\apps_browsers.ahk")
Run("AutoHotkey.exe " A_ScriptDir "\apps_generic.ahk")
Run("AutoHotkey.exe " A_ScriptDir "\apps_houdini.ahk")
Run("AutoHotkey.exe " A_ScriptDir "\apps_unity.ahk")


Run("AutoHotkey.exe " A_ScriptDir "\system_admin.ahk")
Run("AutoHotkey.exe " A_ScriptDir "\system_keyboard.ahk")
Run("AutoHotkey.exe " A_ScriptDir "\system_launcher.ahk")
Run("AutoHotkey.exe " A_ScriptDir "\system_windows.ahk")
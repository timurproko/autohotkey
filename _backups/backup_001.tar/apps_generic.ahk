#Include "%A_ScriptDir%\_mytools\mytools_functions.ahk"
#Requires AutoHotkey >=v2.0
#NoTrayIcon
#SingleInstance Force
KeyHistory(0)
ListLines(false)
ProcessSetPriority("A")
SetWinDelay (-1)
SetKeyDelay (-1, -1, -1)
SetMouseDelay (-1)
SetControlDelay (-1)
A_HotkeyInterval := 0

; Hide
#HotIf WinActive(windowsTeams)
Escape:: WinClose
#HotIf
#HotIf WinActive("Windhawk")
Escape:: WinClose
#HotIf

; Close
#HotIf WinActive(app7zip) or WinActive(appOutlook)
#Escape:: WinClose
#HotIf
#HotIf WinActive(windowsTeams)
#Escape:: ProcessClose ("ms-teams.exe")
#HotIf
#HotIf WinActive(windowsOneDrive)
#Escape:: ProcessClose ("OneDrive.exe")
#HotIf
#HotIf WinActive("ahk_exe speakcli.exe")
Escape:: WinClose
#HotIf

; Enter
#HotIf WinActive(windowsCopilot)
sc01c:: Send("+{sc01c}")
#HotIf
#HotIf WinActive(windowsCopilot)
^sc01c:: Send("{sc01c}")
#HotIf

; Elgato
#HotIf WinActive(appElgatoCameraHub)
Escape:: WinClose
#Escape:: ProcessClose "Camera Hub.exe"
#HotIf

; JetBrains
#HotIf WinActive(appJBRider)
!Space:: Send("^+p")
#HotIf
#HotIf WinActive(appJBToolbox)
#Escape:: Send("^q")
#HotIf

; VSCode
#HotIf WinActive(appVSCode) or WinActive(appCursor)
!Space:: Send("^+p")
#HotIf
#HotIf WinActive(appVSCode)
^+e:: Toggle("^+e", "^b", 1)
^+x:: Toggle("^+x", "^b", 1)
^+f:: Toggle("^+f", "^b", 1)
#HotIf
#HotIf WinActive(appVSCode) and WinExist(appHindie)
Escape:: WinActivate(appHindie)
#HotIf
; #HotIf WinActive(appVSCode) and WinExist(appHoudini)
; Escape:: WinActivate(appHoudini)
; #HotIf

; Spotify
#HotIf WinActive(appSpotify) and A_PriorHotkey = "!Space"
Escape:: Send("{Escape}")
#HotIf
#HotIf WinActive(appSpotify) and A_PriorHotkey != "!Space"
Escape:: ControlApp("close", appSpotify)
#HotIf
#HotIf WinActive(appSpotify)
^Escape:: Send("{Escape}")
!Space:: Send("^k")
^,:: Toggle("^p", "!{Left}", 1)
f8:: Send("{Space}")
f7:: Send("^{Left}")
f9:: Send("^{Right}")
f12:: Send("^{Down}")
f13:: Send("^{Up}")
!0:: Send("!+0")
!1:: Send("!+1")
!2:: Send("!+2")
!3:: Send("!+3")
!4:: Send("!+4")
!5:: Send("!+5")
^+n:: return
^+b:: Send("!+l")
^+f8:: Send("!+j")
#HotIf

; Notion
#HotIf WinActive(appNotion) and A_PriorHotkey = "!Space"
Escape:: Send("{Escape}")
#HotIf
#HotIf WinActive(appNotion) and A_PriorHotkey != "!Space"
Escape:: ControlApp("close", appNotion)
#HotIf
#HotIf WinActive(appNotion)
^Escape:: Send("{Escape}")
!Space:: Send("^p")
^+b:: Send("^\")
!Left:: Send("^[")
!Right:: Send("^]")
#HotIf

; Eagle
#HotIf WinActive(appEagle)
^b:: Send("{f5}")
^e:: Send("^{Enter}")
+Enter:: {
    Send("+{Enter}")
    Sleep 500
    WinClose
}
!Space:: Send("^f")
#HotIf

; 1Password
#HotIf WinActive(app1Password)
^+b:: Send("^+d")
^+d:: return
!Space:: Send("^f")
^LButton:: {
    Send("{LButton}")
    WinClose
}
#HotIf

; MagicPods
#HotIf WinActive(appMagicPods)
Tab:: ClickAtPosition("100%-180px", "160px")
#HotIf

; JBL Quantum App
#HotIf WinActive("ahk_exe QuantumApp.exe")
#Escape:: ProcessClose "QuantumApp.exe"
Escape:: WinClose
#HotIf

; Meta
#HotIf WinActive("ahk_exe Meta Quest Developer Hub.exe")
#Escape:: WinClose
Escape:: WinMinimize
#HotIf

; OBS
#HotIf WinActive(appOBS)
f9:: {
    Send("{f8}")
    WinHide
}
#HotIf

; VLC
#HotIf WinActive(appVLC)
#Escape:: ProcessClose "VLC.exe"
^,:: Send("^p")
=:: Send("]")
-:: Send("[")
0:: Send("=")
[:: return
]:: return
#HotIf

; TunnelBear
#HotIf WinActive(appTunnelBear)
Tab:: ClickAtPosition(130, 50)
#HotIf

; Telegram
#HotIf WinActive(appTelegram) and WinActive("Media viewer")
Left:: return
Right:: return
#HotIf

; Messanger Apps
#HotIf WinActive(appTelegram) or WinActive(appViber) or WinActive(appDiscord)
sc01c:: Send("+{sc01c}")
^sc01c:: Send("{sc01c}")
#HotIf

; Zoom
#HotIf WinActive("Zoom Meeting")
sc01c:: Send("+{sc01c}")
^sc01c:: Send("{sc01c}")
#HotIf
#HotIf WinActive("Zoom Workplace")
Esc:: WinHide
#HotIf

; Steam
#HotIf WinActive("ahk_exe steamwebhelper.exe")
Escape:: WinHide
#Escape:: {
    for proc in [
        "steam.exe",
        "steamwebhelper.exe",
        "steamservice.exe",
        "steamerrorreporter.exe"
    ] {
        try ProcessClose proc
    }
}
#HotIf

; Media Player
#HotIf WinActive(windowsMediaPlayer)
Tab:: Send("{f11}")
Right:: Send("^{Right}")
Left:: Send("^{Left}")
#HotIf

; DaVinci Resolve
#HotIf WinActive(appResolve)
F11:: Send("^f")
#HotIf

; Figma
#HotIf WinActive(appFigma)
#Escape:: WinClose
F2:: Click 2
#HotIf

; FMOD
#HotIf WinActive(appFMOD) and WinGetList(appFMOD).Length > 1
Escape:: WinClose
#HotIf
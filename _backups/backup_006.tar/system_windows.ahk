#Include D:\Dropbox\Configs\AutoHotkey\_scripts\_mytools\mytools_functions.ahk
#Requires AutoHotkey >=v2.0
#NoTrayIcon
#SingleInstance Force
KeyHistory(0)
ListLines(false)
ProcessSetPriority("A")
SetWinDelay (-1)
SetKeyDelay (-1, -1, -1)
SetMouseDelay (-1)
SetControlDelay (-1)
A_HotkeyInterval := 0

if not A_IsAdmin
    Run("*RunAs `"" A_ScriptFullPath "`"")

; Win+A : Allway On Top
#a:: SetAllwayOnTop

; Win+B : System Tray Overflow Window
#b:: ShowTaskbarHiddenIcons

; Win+E : Empty
#e:: return

; Win+F : Maximize
#HotIf !WinActive(windowsTaskbarPopups) and !WinActive(windowsTaskbarTray)
#f:: MyWinMaximize
#HotIf

; Win+I : Empty
#i:: return

; Win+J : Emoji
#j:: Send("#.")

; Win+M : Notification Popup
#m:: Send("#n")

; Win+M : WiFi Popup
#n:: Send("#a")

; Win+O : Empty
#o:: return

; Win+Q : Empty
#q:: return

; Win+S : Screen Capture
#s:: Send("+#s")

; Win+U : Empty
#u:: return

; Alt+V : Paste Without Formatting
!v:: {
    ClipWait
    A_Clipboard := A_Clipboard
    Sleep 10
    Send(Trim(A_Clipboard, "`t`r`n"))
}

; Win+W : Empty
#w:: ControlApp("launch", "explorer.exe")

; Change Language
#f1:: SetLanguage("en")
#f2:: SetLanguage("ru")
#f3:: SetLanguage("ua")

; Win + Backspace : Recycle Bin
#BackSpace:: Run(A_ComSpec " /c `"echo Y|PowerShell -NoProfile -Command Clear-RecycleBin`"", , "Hide")

; F1 : Help
#HotIf WinActive(windowsExplorer)
f1:: return
#HotIf
#HotIf WinActive(browserArc)
f1:: Run windowsHelp
#HotIf

; Refresh
; Windows Explorer
+#r:: {
    RefreshWindowsExplorer
    Sleep TIMEOUT
    WinActivateUnderCursor
}

; Unity
+#u:: ProcessClose "unity.exe"

; Window Management
^LWin Up:: {
    Send("{LWin up}")
    return
}
^#Right:: {
    Send("{LWin down}{Right}")
    return
}
^#Left:: {
    Send("{LWin down}{Left}")
    return
}
^#Up:: {
    Send("{LWin down}{Up}")
    return
}
^#Down:: {

    Send("{LWin down}{Down}")
    return
}

; Task Manager
#Delete:: Send("^+{Escape}")
if (ProcessExist(windowsTaskmgr)) {
    #Escape:: ProcessClose "Taskmgr.exe"
}

; Virtual Desktops
#Right::
{
    SendEvent("{LWin down}{LCtrl down}{Right down}")
    Sleep TIMEOUT
    SendEvent("{Right up}{LWin up}{LCtrl up}")
    return
}
#Left::
{
    SendEvent("{LWin down}{LCtrl down}{Left down}")
    Sleep TIMEOUT
    SendEvent("{Left up}{LWin up}{LCtrl up}")
    return
}
#-:: Send("#^{f4}")
#=:: Send("#^d")

; Passthrough Symbols
#;:: Send(";")  ; Emoji
#.:: Send(".")  ; Emoji
#\:: Send("\")  ; \
#/:: Send("/")  ; /

; Win+\ : Minimize/Activate
#sc056:: {
    if (WinGetStateUnderCursor()) {
        MyWinMinimize
        WinActivateUnderCursor
    } else {
        DeactivateAll
        WinActivateUnderCursor
    }
}

; Win+Space : Search
#HotIf !WinActive(windowsSearch)
#Space:: Send("#s")
#HotIf
#HotIf WinActive(windowsSearch)
#Space:: Send("{Escape}")
#HotIf


; Windows Calculator
#HotIf WinActive(windowsCalculator)
sc059:: Send("{Enter}")
sc067:: Send("%")
sc068:: Send("{Delete}")
sc069:: Send("{Escape}")
sc06A:: Send("{Backspace}")
#HotIf

; Windows Explorer
; Win+H : Show/Hide Hidden Files
#HotIf WinActive(windowsExplorer) and WinActive(windowsExplorerClass)
value2 := RegRead("HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced\", "Hidden", 2)
^+h::
{
    global
    if (value2 = 1)
        value2 := "2"
    else
        value2 := "1"
    RegWrite(value2, "REG_DWORD", "HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced\",
        "Hidden")
    Send("{f5}")
}

; Navigate to Down
!Down:: Send("{Enter}")
#HotIf